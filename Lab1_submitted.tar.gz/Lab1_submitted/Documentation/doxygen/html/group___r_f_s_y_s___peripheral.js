var group___r_f_s_y_s___peripheral =
[
    [ "RFSYS - Register accessor macros", "group___r_f_s_y_s___register___accessor___macros.html", null ],
    [ "RFSYS Register Masks", "group___r_f_s_y_s___register___masks.html", null ],
    [ "RFSYS_MemMap", "struct_r_f_s_y_s___mem_map.html", [
      [ "REG", "struct_r_f_s_y_s___mem_map.html#a9ecc7686e575e2e1570cf50aa3234276", null ]
    ] ],
    [ "RFSYS_BASE_PTR", "group___r_f_s_y_s___peripheral.html#ga2dab66eae1abcaf22879dbce661ea2fa", null ],
    [ "RFSYS_BASE_PTRS", "group___r_f_s_y_s___peripheral.html#ga59f6caa8732744ac3a9f91828ec2daa1", null ],
    [ "RFSYS_MemMapPtr", "group___r_f_s_y_s___peripheral.html#gaea9e2f6aeeb4976615e3c3dd87acff9e", null ]
];