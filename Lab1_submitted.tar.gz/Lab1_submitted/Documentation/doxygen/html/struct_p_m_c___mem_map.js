var struct_p_m_c___mem_map =
[
    [ "LVDSC1", "struct_p_m_c___mem_map.html#aeed619ce4a5bf17bff6201b02deebb54", null ],
    [ "LVDSC2", "struct_p_m_c___mem_map.html#a934db8b39dae8b99a9a9165df50145f5", null ],
    [ "REGSC", "struct_p_m_c___mem_map.html#aa14a55a46cc237589d6c01ebf7676c2a", null ]
];