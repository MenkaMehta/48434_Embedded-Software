var struct_l_d_d___c_a_n___t_frame =
[
    [ "Data", "struct_l_d_d___c_a_n___t_frame.html#ab83c5354d715da8235b37699a4ad790d", null ],
    [ "FrameType", "struct_l_d_d___c_a_n___t_frame.html#aa46516e37548a263726db8a7319c9b2b", null ],
    [ "Length", "struct_l_d_d___c_a_n___t_frame.html#a04016da0d927a62cdcd7316590c3439e", null ],
    [ "LocPriority", "struct_l_d_d___c_a_n___t_frame.html#a4018fbfcb01a60be0b1b57413f103693", null ],
    [ "MessageID", "struct_l_d_d___c_a_n___t_frame.html#ab6f347f42b51e9ae318e04cdce84c82c", null ],
    [ "TimeStamp", "struct_l_d_d___c_a_n___t_frame.html#a9bab04fefdcfc101f718355bc6e20eb4", null ]
];