var struct_v_r_e_f___mem_map =
[
    [ "SC", "struct_v_r_e_f___mem_map.html#a5d8e7e9026a69a14ff0d0b3caee5cf24", null ],
    [ "TRM", "struct_v_r_e_f___mem_map.html#a987ecd280eb0b25ff58841b304de2e1f", null ]
];