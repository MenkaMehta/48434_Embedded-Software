var struct_l_d_d___u_s_b___t_get_decriptor_request___struct =
[
    [ "bDescriptorIndex", "struct_l_d_d___u_s_b___t_get_decriptor_request___struct.html#acdeb70eb4f83efe2fb38cf58aa99e4f1", null ],
    [ "bDescriptorType", "struct_l_d_d___u_s_b___t_get_decriptor_request___struct.html#abfebebabbabe02e816da51fe202282a7", null ],
    [ "bmRequestType", "struct_l_d_d___u_s_b___t_get_decriptor_request___struct.html#a1a1b11552faed99a5e0b5a08c315aa2e", null ],
    [ "bRequest", "struct_l_d_d___u_s_b___t_get_decriptor_request___struct.html#aa7651472aa5110086f335c0b79c0bc5b", null ],
    [ "wLanguageID", "struct_l_d_d___u_s_b___t_get_decriptor_request___struct.html#a228c41af26c45c1fa18d964c0702a4b4", null ],
    [ "wLength", "struct_l_d_d___u_s_b___t_get_decriptor_request___struct.html#af9ac7409b4031aa6f3ec5da9d79b06eb", null ]
];