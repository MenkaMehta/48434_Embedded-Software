var struct_l_d_d___l_c_d_c___t_window =
[
    [ "Height", "struct_l_d_d___l_c_d_c___t_window.html#abe1dbefb6d43373336fa414b88a79cc2", null ],
    [ "Width", "struct_l_d_d___l_c_d_c___t_window.html#a53ee53813f5884a400be8ca3093233c4", null ],
    [ "X", "struct_l_d_d___l_c_d_c___t_window.html#a9dd1270e9794b4dbd79b2b30afca87c9", null ],
    [ "Y", "struct_l_d_d___l_c_d_c___t_window.html#af64f532d1fb5899c563ba40df90867d8", null ]
];