var struct_l_d_d___s_d_h_c___t_card_write_protect =
[
    [ "GroupSize", "struct_l_d_d___s_d_h_c___t_card_write_protect.html#ae05b5dd538cf47f5ec24559246415306", null ],
    [ "Permanent", "struct_l_d_d___s_d_h_c___t_card_write_protect.html#aff6b0178087c770234bd68974d643552", null ]
];