var struct_l_d_d___s_s_i___t_a_c97_command =
[
    [ "Address", "struct_l_d_d___s_s_i___t_a_c97_command.html#a0d39df5cae85e73b036af81e9fbc6332", null ],
    [ "Data", "struct_l_d_d___s_s_i___t_a_c97_command.html#abc16535d09d61f2c3f885adf91632117", null ],
    [ "Type", "struct_l_d_d___s_s_i___t_a_c97_command.html#ac7226beaf57a764f71faf7e822e27a6e", null ]
];