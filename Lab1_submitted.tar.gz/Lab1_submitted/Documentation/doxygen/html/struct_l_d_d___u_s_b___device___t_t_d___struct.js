var struct_l_d_d___u_s_b___device___t_t_d___struct =
[
    [ "CallbackFnPtr", "struct_l_d_d___u_s_b___device___t_t_d___struct.html#aaff3a74a2abea1e6b530ecfdaff8c584", null ],
    [ "Head", "struct_l_d_d___u_s_b___device___t_t_d___struct.html#a7f3947a676f6ecd32e3fb342b7f07a35", null ],
    [ "ParamPtr", "struct_l_d_d___u_s_b___device___t_t_d___struct.html#ab1f3a3912ae70d748c5891aa91804de4", null ],
    [ "TransferState", "struct_l_d_d___u_s_b___device___t_t_d___struct.html#aca23e3743f56dc73206b79f885e9130f", null ],
    [ "TransmittedDataSize", "struct_l_d_d___u_s_b___device___t_t_d___struct.html#aeffbf1300fce5fc9ebf98f5760a96d38", null ]
];