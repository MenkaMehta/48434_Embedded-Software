var struct_l_d_d___s_p_i_m_a_s_t_e_r___t_stats =
[
    [ "RxChars", "struct_l_d_d___s_p_i_m_a_s_t_e_r___t_stats.html#a6faa4c57f364f06f5cd3770a7686ef6f", null ],
    [ "RxOverruns", "struct_l_d_d___s_p_i_m_a_s_t_e_r___t_stats.html#a528cf1d78c49b42ae455ba895987ece5", null ],
    [ "RxParityErrors", "struct_l_d_d___s_p_i_m_a_s_t_e_r___t_stats.html#a83f9f4b7598e6d84e6842539cc54619f", null ],
    [ "TxChars", "struct_l_d_d___s_p_i_m_a_s_t_e_r___t_stats.html#af5376883e99d71f857999d58b2888f95", null ]
];