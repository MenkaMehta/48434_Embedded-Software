var unionint16union__t =
[
    [ "Hi", "unionint16union__t.html#aebf3b897adab5ed0a5bfc64159bd58aa", null ],
    [ "l", "unionint16union__t.html#ad8a9524a204892ae3d42a2d251ea0643", null ],
    [ "Lo", "unionint16union__t.html#a90626557ee63dcc8d3704100754b2cdf", null ],
    [ "s", "unionint16union__t.html#a862947ae5f02cb03bb2bb9b66be56d46", null ]
];