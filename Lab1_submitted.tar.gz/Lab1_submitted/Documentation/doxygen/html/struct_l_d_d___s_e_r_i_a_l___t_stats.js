var struct_l_d_d___s_e_r_i_a_l___t_stats =
[
    [ "FramingErrors", "struct_l_d_d___s_e_r_i_a_l___t_stats.html#a7aa38e2a0215c73f11a5ec2e2db4c39b", null ],
    [ "NoiseErrors", "struct_l_d_d___s_e_r_i_a_l___t_stats.html#a024bac3a1be777c32d07a835f4c42878", null ],
    [ "OverrunErrors", "struct_l_d_d___s_e_r_i_a_l___t_stats.html#aa8a7fee8c6a608b49b8ec1b5a603c536", null ],
    [ "ParityErrors", "struct_l_d_d___s_e_r_i_a_l___t_stats.html#aba7800197922c7effa1eef7f5f5bbd0b", null ],
    [ "ReceivedBreaks", "struct_l_d_d___s_e_r_i_a_l___t_stats.html#a45f707461666b974a6c3b5c948e66cf7", null ],
    [ "ReceivedChars", "struct_l_d_d___s_e_r_i_a_l___t_stats.html#a7dd5faa8bc6c15fde011eb6192ca6168", null ],
    [ "SentChars", "struct_l_d_d___s_e_r_i_a_l___t_stats.html#a60198f844b85f9e73efaca83e32471cd", null ]
];