var struct_l_d_d___c_a_n___t_stats =
[
    [ "AckErrors", "struct_l_d_d___c_a_n___t_stats.html#aa2f78bb4fe62158e98a24389bf5c9d3f", null ],
    [ "Bit0Errors", "struct_l_d_d___c_a_n___t_stats.html#a5b1d814077cb713499d7a95e91719552", null ],
    [ "Bit1Errors", "struct_l_d_d___c_a_n___t_stats.html#a0c580b25ec28e467601580e79e7137d4", null ],
    [ "BitStuffErrors", "struct_l_d_d___c_a_n___t_stats.html#a811a427adbc75325167b5073963c676a", null ],
    [ "BusOffs", "struct_l_d_d___c_a_n___t_stats.html#aa01ae74140765599c87675e5df7d8a3d", null ],
    [ "CrcErrors", "struct_l_d_d___c_a_n___t_stats.html#a27e16f4ddc9cdf544026c4d6ce7b698f", null ],
    [ "Errors", "struct_l_d_d___c_a_n___t_stats.html#a9540270ab882bd0afa615b87afb9e6b3", null ],
    [ "FormErrors", "struct_l_d_d___c_a_n___t_stats.html#a0d783d7e8813ded41cdac8181bab524a", null ],
    [ "RxFrames", "struct_l_d_d___c_a_n___t_stats.html#ad5fce5f144966e6ef1ebd3559573c5cc", null ],
    [ "RxWarnings", "struct_l_d_d___c_a_n___t_stats.html#a9454eaee94ea556f10485bd8608bf980", null ],
    [ "TxFrames", "struct_l_d_d___c_a_n___t_stats.html#ad6e8656da94718393be3b05ef07a5fe0", null ],
    [ "TxWarnings", "struct_l_d_d___c_a_n___t_stats.html#a46ea9a5839da88b7e7b596ac34b72f90", null ],
    [ "Wakeups", "struct_l_d_d___c_a_n___t_stats.html#ab59425105119b5b6496a6e0fcc8398d5", null ]
];