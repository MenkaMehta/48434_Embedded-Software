var struct_l_d_d___u_s_b___device___t_t_d___head___struct =
[
    [ "BufferPtr", "struct_l_d_d___u_s_b___device___t_t_d___head___struct.html#aa1830a973aab07b39899cf4435b8aa26", null ],
    [ "BufferSize", "struct_l_d_d___u_s_b___device___t_t_d___head___struct.html#ad04ab3cfb7cab97abbba9dfc3c43f1a0", null ],
    [ "EpNum", "struct_l_d_d___u_s_b___device___t_t_d___head___struct.html#ab3874883985b845f4e4be39240793543", null ],
    [ "Flags", "struct_l_d_d___u_s_b___device___t_t_d___head___struct.html#a9572bb866ff1f22ed881f3ff618c0445", null ]
];