var group___d_m_a_m_u_x___peripheral =
[
    [ "DMAMUX - Register accessor macros", "group___d_m_a_m_u_x___register___accessor___macros.html", null ],
    [ "DMAMUX Register Masks", "group___d_m_a_m_u_x___register___masks.html", null ],
    [ "DMAMUX_MemMap", "struct_d_m_a_m_u_x___mem_map.html", [
      [ "CHCFG", "struct_d_m_a_m_u_x___mem_map.html#a7ba04adde18230ace5b01e6b01725638", null ]
    ] ],
    [ "DMAMUX0_BASE_PTR", "group___d_m_a_m_u_x___peripheral.html#ga403b61d306820e4e1113c636300004a3", null ],
    [ "DMAMUX1_BASE_PTR", "group___d_m_a_m_u_x___peripheral.html#gad6b43366c6448bd157f17be565d8e1f3", null ],
    [ "DMAMUX_BASE_PTRS", "group___d_m_a_m_u_x___peripheral.html#gaad218c12978071501dc2899f0624de4b", null ],
    [ "DMAMUX_MemMapPtr", "group___d_m_a_m_u_x___peripheral.html#ga736ab5b1ed284b3b4fdb63010a576777", null ]
];