var group___o_s_c___peripheral =
[
    [ "OSC - Register accessor macros", "group___o_s_c___register___accessor___macros.html", null ],
    [ "OSC Register Masks", "group___o_s_c___register___masks.html", null ],
    [ "OSC_MemMap", "struct_o_s_c___mem_map.html", [
      [ "CR", "struct_o_s_c___mem_map.html#adb3c443099915a22c9951ff23c8eaa16", null ]
    ] ],
    [ "OSC0_BASE_PTR", "group___o_s_c___peripheral.html#gaab1618c69a91b2e5d3385139b5b566f0", null ],
    [ "OSC1_BASE_PTR", "group___o_s_c___peripheral.html#ga5a0e46e15931232a6e0cafb7315041fa", null ],
    [ "OSC_BASE_PTRS", "group___o_s_c___peripheral.html#ga46f69fcb9d660e18b5cbf51adbbcec78", null ],
    [ "OSC_MemMapPtr", "group___o_s_c___peripheral.html#gaaa685163f549fdf24c28ec9b400310b5", null ]
];