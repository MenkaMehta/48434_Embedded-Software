var struct_l_d_d___u_s_b___t_set_address_request___struct =
[
    [ "bmRequestType", "struct_l_d_d___u_s_b___t_set_address_request___struct.html#aff2ef69da69a7765e4751f3d1b10bc36", null ],
    [ "bRequest", "struct_l_d_d___u_s_b___t_set_address_request___struct.html#a0c2e1dccfc6d1a0fa8e0997a1e1db1a1", null ],
    [ "bValueHigh", "struct_l_d_d___u_s_b___t_set_address_request___struct.html#a1a73dd5b67a7394d38d440d99ca2b773", null ],
    [ "DeviceAddress", "struct_l_d_d___u_s_b___t_set_address_request___struct.html#ac55059f77c050ba97d5f0d9b2b3a52c9", null ],
    [ "wIndex", "struct_l_d_d___u_s_b___t_set_address_request___struct.html#ab6a26adfbbc2e164679a4d7dcf5c99d0", null ],
    [ "wLength", "struct_l_d_d___u_s_b___t_set_address_request___struct.html#adff24e6d3ec27fce1f59693aa215deda", null ]
];