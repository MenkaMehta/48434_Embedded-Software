var struct_l_d_d___u_s_b___host___t_t_d___struct =
[
    [ "BufferPtr", "struct_l_d_d___u_s_b___host___t_t_d___struct.html#a47f0b9494933fcc95c6cbe51a43fff71", null ],
    [ "BufferSize", "struct_l_d_d___u_s_b___host___t_t_d___struct.html#a953e14b8b2f530f5523257faa642b44f", null ],
    [ "CallbackFnPtr", "struct_l_d_d___u_s_b___host___t_t_d___struct.html#aa4c4dbcecc75dfa056795c35cc7b0a0b", null ],
    [ "Flags", "struct_l_d_d___u_s_b___host___t_t_d___struct.html#a083f54cb9e59a2206aca7d5481154c27", null ],
    [ "ParamPtr", "struct_l_d_d___u_s_b___host___t_t_d___struct.html#ab6fd6fdfe1e3e43cbdb5e1f2f61b3265", null ],
    [ "SDPPrt", "struct_l_d_d___u_s_b___host___t_t_d___struct.html#af1881ea197419558fdb55dc5f98ee446", null ]
];