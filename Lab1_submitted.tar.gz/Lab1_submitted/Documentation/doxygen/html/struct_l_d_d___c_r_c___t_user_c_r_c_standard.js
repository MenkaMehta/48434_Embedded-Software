var struct_l_d_d___c_r_c___t_user_c_r_c_standard =
[
    [ "InputTransposeMode", "struct_l_d_d___c_r_c___t_user_c_r_c_standard.html#aa3a966168a0b5279263c7aa799e0761f", null ],
    [ "OutputTransposeMode", "struct_l_d_d___c_r_c___t_user_c_r_c_standard.html#a65722aaaf3999108edb36dd618e0caf0", null ],
    [ "PolyHigh", "struct_l_d_d___c_r_c___t_user_c_r_c_standard.html#a69fe65fd5d7f8551e202a94e5a666b65", null ],
    [ "PolyLow", "struct_l_d_d___c_r_c___t_user_c_r_c_standard.html#a7740ed310d2acb019b646e3e51e96e7a", null ],
    [ "ResultXORed", "struct_l_d_d___c_r_c___t_user_c_r_c_standard.html#ab4ae7517be7d1ae18552df085bfb2b53", null ],
    [ "SeedHigh", "struct_l_d_d___c_r_c___t_user_c_r_c_standard.html#a1618ebd5b27d9e71598e19df7ebbc1c8", null ],
    [ "SeedLow", "struct_l_d_d___c_r_c___t_user_c_r_c_standard.html#a4add9670995777c55ffde5d6abec885c", null ],
    [ "Width32bit", "struct_l_d_d___c_r_c___t_user_c_r_c_standard.html#a82a24fa9104800759f278afc36a4e00e", null ]
];