var struct_r_f_v_b_a_t___mem_map =
[
    [ "REG", "struct_r_f_v_b_a_t___mem_map.html#a21ddc52aa162e182f22011520b5bf93b", null ]
];