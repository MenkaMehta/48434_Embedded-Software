var struct_l_d_d___u_s_b___t_s_d_p___struct =
[
    [ "bmRequestType", "struct_l_d_d___u_s_b___t_s_d_p___struct.html#afddb7f5f46fc265c07889888d1307a79", null ],
    [ "bRequest", "struct_l_d_d___u_s_b___t_s_d_p___struct.html#a38ea083d899a28927d0de58dd646054f", null ],
    [ "wIndex", "struct_l_d_d___u_s_b___t_s_d_p___struct.html#af04dcae50f0c8d6b27bd1e70f1af89d6", null ],
    [ "wLength", "struct_l_d_d___u_s_b___t_s_d_p___struct.html#a9015bd09ca306fdb49943219fafe3fe3", null ],
    [ "wValue", "struct_l_d_d___u_s_b___t_s_d_p___struct.html#abe97822a1a8976f53da5a43b8db8cfd3", null ]
];