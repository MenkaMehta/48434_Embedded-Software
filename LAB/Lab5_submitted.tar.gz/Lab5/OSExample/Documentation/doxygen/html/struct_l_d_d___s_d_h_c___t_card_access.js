var struct_l_d_d___s_d_h_c___t_card_access =
[
    [ "MaxBlockLength", "struct_l_d_d___s_d_h_c___t_card_access.html#aeeba296e7a8dc6164c925b816416ef2e", null ],
    [ "MisalignBlock", "struct_l_d_d___s_d_h_c___t_card_access.html#aa56e65353fd03ffdbd8cc8d19537b621", null ],
    [ "PartialBlock", "struct_l_d_d___s_d_h_c___t_card_access.html#a9d78668915e934548a04351b20ec2d0a", null ]
];