var struct_l_d_d___a_d_c___t_sample =
[
    [ "ChannelIdx", "struct_l_d_d___a_d_c___t_sample.html#ae2737bdf799311a9bc9f7acf30f569c1", null ]
];