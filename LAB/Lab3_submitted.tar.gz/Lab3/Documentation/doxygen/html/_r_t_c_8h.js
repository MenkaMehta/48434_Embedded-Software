var _r_t_c_8h =
[
    [ "__attribute__", "group___r_t_c__module.html#ga445500277ba0e363873b34cffc015745", null ],
    [ "RTC_Get", "group___r_t_c__module.html#ga46e1f15e3b27e2de58d7f213a3bc865d", null ],
    [ "RTC_Init", "group___r_t_c__module.html#ga1eff20f412d72f94182b7fca0b3b0925", null ],
    [ "RTC_Set", "group___r_t_c__module.html#gacbe916e4fad6bfc2ffcde604fa6afb52", null ]
];