var struct_l_d_d___d_m_a___t_error =
[
    [ "ChannelNumber", "struct_l_d_d___d_m_a___t_error.html#abc8d0c6909178bc7fe3957b7c01afd08", null ],
    [ "ErrorFlags", "struct_l_d_d___d_m_a___t_error.html#a9dd0a645e1763b4daa0058b1b29c4ad7", null ]
];