var group__fifo__module =
[
    [ "TFIFO", "struct_t_f_i_f_o.html", [
      [ "Buffer", "struct_t_f_i_f_o.html#a5a9d712880dc4f1d5571b96452cd85f8", null ],
      [ "End", "struct_t_f_i_f_o.html#a5063b875898a6f23a97aa3ca17f0544b", null ],
      [ "NbBytes", "struct_t_f_i_f_o.html#ace00017651a266a66a93aa5220967611", null ],
      [ "Start", "struct_t_f_i_f_o.html#a092a7559431a12616672354641908167", null ]
    ] ],
    [ "FIFO_Get", "group__fifo__module.html#ga6407e3daf24a826a7f17d3e48865e89a", null ],
    [ "FIFO_Init", "group__fifo__module.html#gad9207f49ab9ed061b6dca6063112ca60", null ],
    [ "FIFO_Put", "group__fifo__module.html#gace64ba4e6bd943f990a294693156cc3b", null ]
];