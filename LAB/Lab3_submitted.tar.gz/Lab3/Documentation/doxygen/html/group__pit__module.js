var group__pit__module =
[
    [ "__attribute__", "group__pit__module.html#ga445500277ba0e363873b34cffc015745", null ],
    [ "PIT_Enable", "group__pit__module.html#gaed902f6158d6681e4b05d078575e4b09", null ],
    [ "PIT_Init", "group__pit__module.html#gae69097a83912a25b357df1046aea9b52", null ],
    [ "PIT_Set", "group__pit__module.html#gae012c6f6b7396828c558c92ad0a27ed5", null ]
];