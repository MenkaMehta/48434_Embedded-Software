var struct_l_d_d___r_t_c___t_time =
[
    [ "Day", "struct_l_d_d___r_t_c___t_time.html#acc1084e0fd686c588a2947c2f109634f", null ],
    [ "DayOfWeek", "struct_l_d_d___r_t_c___t_time.html#a43ba06409c4d35f48d732cb61ff5aed0", null ],
    [ "Hour", "struct_l_d_d___r_t_c___t_time.html#ade2d4bed82069483da14cfe2ede6fef9", null ],
    [ "Minute", "struct_l_d_d___r_t_c___t_time.html#a5cd7a1478dd5dd319fb5837bfbf5459f", null ],
    [ "Month", "struct_l_d_d___r_t_c___t_time.html#a2de1da3c8e42665975c2469125b04dfd", null ],
    [ "Second", "struct_l_d_d___r_t_c___t_time.html#ab6c770706c18542e856d56398850ac9e", null ],
    [ "Year", "struct_l_d_d___r_t_c___t_time.html#a16fbfb74b239e4b5e1889fe19d025d5e", null ]
];