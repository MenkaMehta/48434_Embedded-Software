var struct_l_d_d___time_date___t_time_rec =
[
    [ "Hour", "struct_l_d_d___time_date___t_time_rec.html#ac741c5c14148b2d360bb09fedc6ebabd", null ],
    [ "Min", "struct_l_d_d___time_date___t_time_rec.html#a7cea2c409e90bccdc33f19b093020373", null ],
    [ "Sec", "struct_l_d_d___time_date___t_time_rec.html#a05cccc86e89e5704b0460caaf2429f75", null ],
    [ "Sec100", "struct_l_d_d___time_date___t_time_rec.html#a2cd2e13e7c478f04ea1c4c460b104491", null ]
];