var struct_l_d_d___s_s_i___t_data_blocks =
[
    [ "Channel0Ptr", "struct_l_d_d___s_s_i___t_data_blocks.html#a8b1b9f1fd6075f9d9975f1506ac64a16", null ],
    [ "Channel1Ptr", "struct_l_d_d___s_s_i___t_data_blocks.html#a5c0e65fe82f88a245123217769316fef", null ]
];