var group___s_c_b___peripheral =
[
    [ "SCB - Register accessor macros", "group___s_c_b___register___accessor___macros.html", null ],
    [ "SCB Register Masks", "group___s_c_b___register___masks.html", null ],
    [ "SCB_MemMap", "struct_s_c_b___mem_map.html", [
      [ "ACTLR", "struct_s_c_b___mem_map.html#a474a33074611146734690e48ed41282e", null ],
      [ "AFSR", "struct_s_c_b___mem_map.html#aa02bdd6294d9240a566fe92085f62ae1", null ],
      [ "AIRCR", "struct_s_c_b___mem_map.html#a3f874ca1c6e17ae4beadac22e8ec17ec", null ],
      [ "BFAR", "struct_s_c_b___mem_map.html#a57e3932788931280ee70b7389c4b23f4", null ],
      [ "CCR", "struct_s_c_b___mem_map.html#aa6e957027d8c505047cd58101bb784aa", null ],
      [ "CFSR", "struct_s_c_b___mem_map.html#a51c6a21cb789c655257efe5796c7f503", null ],
      [ "CPACR", "struct_s_c_b___mem_map.html#aa863fcf3f6eca09d9caec27247b017ae", null ],
      [ "CPUID", "struct_s_c_b___mem_map.html#ad020795dcc3605b4c828af83df8b8836", null ],
      [ "DFSR", "struct_s_c_b___mem_map.html#af178d6003a18eb7452c51edcec14ec5d", null ],
      [ "HFSR", "struct_s_c_b___mem_map.html#a7f0b5d6f24446f1f603a6d9ef6259de2", null ],
      [ "ICSR", "struct_s_c_b___mem_map.html#aafbaa0d0a4b79969877c9b84be8aaf7a", null ],
      [ "MMFAR", "struct_s_c_b___mem_map.html#af81b60a951ac45ddc8376500ed1580ef", null ],
      [ "RESERVED_0", "struct_s_c_b___mem_map.html#ad1b50f88903f5b63f2b92b7195511d00", null ],
      [ "RESERVED_1", "struct_s_c_b___mem_map.html#ab112bcf2a89a8f23d7c0a9f7c2ba687b", null ],
      [ "RESERVED_2", "struct_s_c_b___mem_map.html#a5c9626f34253e346f67a00a489dfc9b9", null ],
      [ "SCR", "struct_s_c_b___mem_map.html#ac8d0a0d974bde944d42429065dd2f44a", null ],
      [ "SHCSR", "struct_s_c_b___mem_map.html#ae2b73d4b9744b878527466ec57dbfdb7", null ],
      [ "SHPR1", "struct_s_c_b___mem_map.html#afe02d5ca0102ec35b79172d453854ed0", null ],
      [ "SHPR2", "struct_s_c_b___mem_map.html#a1636322022eb10e4acedf40018708b68", null ],
      [ "SHPR3", "struct_s_c_b___mem_map.html#a8ac3a3b8dd23fb279640b98a95fb796a", null ],
      [ "VTOR", "struct_s_c_b___mem_map.html#aa327db1d9948595498fba43acc8d336b", null ]
    ] ],
    [ "SCB_BASE_PTRS", "group___s_c_b___peripheral.html#gaf74b4dbfa6fd0a5607314e170a0c1d48", null ],
    [ "SystemControl_BASE_PTR", "group___s_c_b___peripheral.html#gaf22864785770f832103e904244e078cb", null ],
    [ "SCB_MemMapPtr", "group___s_c_b___peripheral.html#ga08aca299c99cac47121d9e64e7b8e1cf", null ]
];