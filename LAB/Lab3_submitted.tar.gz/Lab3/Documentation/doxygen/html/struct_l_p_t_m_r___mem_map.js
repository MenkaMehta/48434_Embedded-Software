var struct_l_p_t_m_r___mem_map =
[
    [ "CMR", "struct_l_p_t_m_r___mem_map.html#a28ac745e518d40e34527f5cf70f75d70", null ],
    [ "CNR", "struct_l_p_t_m_r___mem_map.html#adda036ea26ea5cc89d7957779c5680f0", null ],
    [ "CSR", "struct_l_p_t_m_r___mem_map.html#a4dcb593756f09d67e3d064d95e3f2d68", null ],
    [ "PSR", "struct_l_p_t_m_r___mem_map.html#a05f0c5c90722e5a1757c262c818d2462", null ]
];