var group__ftm__module =
[
    [ "TFTMChannel", "struct_t_f_t_m_channel.html", [
      [ "channelNb", "struct_t_f_t_m_channel.html#aa2404895d5318fcd6aecab3147c14826", null ],
      [ "delayCount", "struct_t_f_t_m_channel.html#abb555760e71da6a4822a1ace343381f2", null ],
      [ "inputDetection", "struct_t_f_t_m_channel.html#a2dfe9a7595629343ee930e9e80f1f707", null ],
      [ "ioType", "struct_t_f_t_m_channel.html#a22686eb260620d38f2de4b311e5ed02e", null ],
      [ "outputAction", "struct_t_f_t_m_channel.html#ace675e50da5484889a79a34754ab9ff2", null ],
      [ "timerFunction", "struct_t_f_t_m_channel.html#aa5f3d62a353d779117ced0877fa47734", null ],
      [ "userArguments", "struct_t_f_t_m_channel.html#a975090ae478158776d52eb24660021d6", null ],
      [ "userFunction", "struct_t_f_t_m_channel.html#af3920191861032f55e27bd4fd42cb29a", null ]
    ] ],
    [ "FTM_Init", "group__ftm__module.html#ga5f31811e067b5690d5f73c8e77019a6b", null ],
    [ "FTM_Set", "group__ftm__module.html#gae4928af832114c8173e43d10e4144c1f", null ],
    [ "FTM_StartTimer", "group__ftm__module.html#gabb34a0dd79d879502fd81c0efa9440ec", null ]
];