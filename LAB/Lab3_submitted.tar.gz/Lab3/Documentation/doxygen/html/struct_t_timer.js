var struct_t_timer =
[
    [ "channelNb", "struct_t_timer.html#aa4d8d30434328fb03e302cdd084145e9", null ],
    [ "initialCount", "struct_t_timer.html#a4df06f73d9698b9f2f84ecbe2c40daf0", null ],
    [ "inputDetection", "struct_t_timer.html#a3895299d7686bdf6f8003d078ad77769", null ],
    [ "ioType", "struct_t_timer.html#af247dd98ad511144a2c57b6c6c626c97", null ],
    [ "outputAction", "struct_t_timer.html#ab8d67dbe25505490da1c242e44100a8f", null ],
    [ "timerFunction", "struct_t_timer.html#a8d493df0d66a9fdecfc42cc73f44574b", null ],
    [ "userArguments", "struct_t_timer.html#ae3c5a5d7159e52b6cb63b1196ffcd35f", null ],
    [ "userFunction", "struct_t_timer.html#ad220fb9c91803d973d7ae23e7be7fc03", null ]
];