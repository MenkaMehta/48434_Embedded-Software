var struct_l_d_d___u_s_b___t_endpoint_feature_request___struct =
[
    [ "bEndpoint", "struct_l_d_d___u_s_b___t_endpoint_feature_request___struct.html#a411af4337f39b9553d65d73bee6af5ec", null ],
    [ "bIndexHigh", "struct_l_d_d___u_s_b___t_endpoint_feature_request___struct.html#aeec172fdf61100889cd7f70958283f48", null ],
    [ "bmRequestType", "struct_l_d_d___u_s_b___t_endpoint_feature_request___struct.html#adc137c604066ff6d3c614dbaa2cb225f", null ],
    [ "bRequest", "struct_l_d_d___u_s_b___t_endpoint_feature_request___struct.html#acd2dcd4a8762d22f84cfe3b9d9607a25", null ],
    [ "wFeatureSelector", "struct_l_d_d___u_s_b___t_endpoint_feature_request___struct.html#aa026e7ce420430dc65a72dcc10337553", null ],
    [ "wLength", "struct_l_d_d___u_s_b___t_endpoint_feature_request___struct.html#aec7dc034039bc4deb5c811afac0686a5", null ]
];