var struct_l_d_d___time_date___t_date_rec =
[
    [ "Day", "struct_l_d_d___time_date___t_date_rec.html#a6f1463c1917d6fe55a492bdb85a6bd17", null ],
    [ "DayOfWeek", "struct_l_d_d___time_date___t_date_rec.html#a11ed8bc2e3fbd80252a7d4802d316f1c", null ],
    [ "Month", "struct_l_d_d___time_date___t_date_rec.html#a28aaeffe98b07d60db379d12269fa822", null ],
    [ "Year", "struct_l_d_d___time_date___t_date_rec.html#a58eee644efb4f46adc3437063c7bc194", null ]
];