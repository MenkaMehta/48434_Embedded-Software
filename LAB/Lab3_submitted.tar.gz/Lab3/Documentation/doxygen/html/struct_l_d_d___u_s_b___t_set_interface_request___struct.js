var struct_l_d_d___u_s_b___t_set_interface_request___struct =
[
    [ "bmRequestType", "struct_l_d_d___u_s_b___t_set_interface_request___struct.html#a1fe15bb3812990d990658d5e22f3742b", null ],
    [ "bRequest", "struct_l_d_d___u_s_b___t_set_interface_request___struct.html#a5caed41b8435790d8f87b9dc86502bde", null ],
    [ "wAltSet", "struct_l_d_d___u_s_b___t_set_interface_request___struct.html#a2aa95c4285e3fa36c3cf7df4bb40f1d0", null ],
    [ "wInterface", "struct_l_d_d___u_s_b___t_set_interface_request___struct.html#a6554d6522c7dcbd0e96cbe945b1725de", null ],
    [ "wLength", "struct_l_d_d___u_s_b___t_set_interface_request___struct.html#a7ccdd1f214e5cebbc10cde359ccba50e", null ]
];