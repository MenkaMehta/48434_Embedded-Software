var struct_p_o_r_t___mem_map =
[
    [ "DFCR", "struct_p_o_r_t___mem_map.html#a0d2552c73fb3c6ed5f336d7df1249151", null ],
    [ "DFER", "struct_p_o_r_t___mem_map.html#ad472de7afdaeef3985761041fe9023e2", null ],
    [ "DFWR", "struct_p_o_r_t___mem_map.html#a739d09875cabb44276b89977d36a19ed", null ],
    [ "GPCHR", "struct_p_o_r_t___mem_map.html#a84f8893cbefd6a3eff18b455f9069b29", null ],
    [ "GPCLR", "struct_p_o_r_t___mem_map.html#a837c289643f8cec958b1f01c086b558a", null ],
    [ "ISFR", "struct_p_o_r_t___mem_map.html#a53c86a08f430dc915a312efe74ba83e6", null ],
    [ "PCR", "struct_p_o_r_t___mem_map.html#a1c54a8f1741fade8daf28198fee43ddd", null ],
    [ "RESERVED_0", "struct_p_o_r_t___mem_map.html#ad85e48d2b0e879333bf0dcb5a0af21f5", null ],
    [ "RESERVED_1", "struct_p_o_r_t___mem_map.html#acf6fba14d96a0e52de37d90eb15c0324", null ]
];