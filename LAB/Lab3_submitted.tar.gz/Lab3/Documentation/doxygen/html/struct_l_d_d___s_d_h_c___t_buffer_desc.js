var struct_l_d_d___s_d_h_c___t_buffer_desc =
[
    [ "DataPtr", "struct_l_d_d___s_d_h_c___t_buffer_desc.html#a0349f594a37791792e4a213111173a68", null ],
    [ "Size", "struct_l_d_d___s_d_h_c___t_buffer_desc.html#a117f5acff1ada72194a95b38795bca56", null ]
];