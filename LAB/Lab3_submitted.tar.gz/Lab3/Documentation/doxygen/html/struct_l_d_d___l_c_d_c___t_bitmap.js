var struct_l_d_d___l_c_d_c___t_bitmap =
[
    [ "Address", "struct_l_d_d___l_c_d_c___t_bitmap.html#a5501acee73fa929201a06eccc4821a7a", null ],
    [ "Format", "struct_l_d_d___l_c_d_c___t_bitmap.html#a8f886a6ce6e67d4b070c20bdd5ce495a", null ],
    [ "Height", "struct_l_d_d___l_c_d_c___t_bitmap.html#a13fea31674709c4f681e6c86d3b71206", null ],
    [ "Width", "struct_l_d_d___l_c_d_c___t_bitmap.html#af88017bd29e49292265c1fda6dc5463d", null ]
];