var struct_l_d_d___i2_c___t_stats =
[
    [ "ArbitLost", "struct_l_d_d___i2_c___t_stats.html#ac11389cb67b62b2dd63ac5390c47c1b1", null ],
    [ "MasterNacks", "struct_l_d_d___i2_c___t_stats.html#a451fe2a61e5c5dac8f1846987ad47af8", null ],
    [ "MasterReceivedChars", "struct_l_d_d___i2_c___t_stats.html#a3278bb4aa5e4223e199e9aee14e8f2fe", null ],
    [ "MasterSentChars", "struct_l_d_d___i2_c___t_stats.html#a9b4d75a976e9c6031513b31948396c6a", null ],
    [ "SCLLowTimeout", "struct_l_d_d___i2_c___t_stats.html#af6af8ae5b9414298f9a0e5d065c6f3d8", null ],
    [ "SDALowTimeout", "struct_l_d_d___i2_c___t_stats.html#a9f3bfd5d01433711d763f893192da34e", null ],
    [ "SlaveGeneralCallAddr", "struct_l_d_d___i2_c___t_stats.html#ac197175a686624b673584bf24e56b8ab", null ],
    [ "SlaveReceivedChars", "struct_l_d_d___i2_c___t_stats.html#a1f5f4c88b26ee91ad3ade3182c83b359", null ],
    [ "SlaveRxOverrun", "struct_l_d_d___i2_c___t_stats.html#afe6c0b4f10465050a22af12bb0d8cd00", null ],
    [ "SlaveSentChars", "struct_l_d_d___i2_c___t_stats.html#ad4935dd9ff320dcc83fe33f388713c85", null ],
    [ "SlaveSmBusAlertResponse", "struct_l_d_d___i2_c___t_stats.html#a8013f91bdae1fc4fddf111aa1e2a52ca", null ],
    [ "SlaveSmBusCallAddr", "struct_l_d_d___i2_c___t_stats.html#a134cb9fb9e37217e70e8a93924bca300", null ],
    [ "SlaveTxUnderrun", "struct_l_d_d___i2_c___t_stats.html#add2f9914a1ea98c3bf86c0cab84e6a8c", null ]
];