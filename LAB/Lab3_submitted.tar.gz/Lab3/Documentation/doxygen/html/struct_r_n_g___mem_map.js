var struct_r_n_g___mem_map =
[
    [ "CR", "struct_r_n_g___mem_map.html#a45a3eac94c475645b527fcfbef3449b2", null ],
    [ "ER", "struct_r_n_g___mem_map.html#a00c023d8dafb81ac55c86b3ad8decb3d", null ],
    [ "OR", "struct_r_n_g___mem_map.html#a28a39f4167d28546cea918687d2951f1", null ],
    [ "SR", "struct_r_n_g___mem_map.html#a5d258b2ed1915070a6d3651092d8f3c7", null ]
];