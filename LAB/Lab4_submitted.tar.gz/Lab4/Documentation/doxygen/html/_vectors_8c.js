var _vectors_8c =
[
    [ "__attribute__", "group___vectors__module.html#ga0032ad18571ad670d92872faa8879886", null ],
    [ "__thumb_startup", "group___vectors__module.html#ga1291096ffdfeb4d928a6020b5e9a8ccc", null ],
    [ "__SP_INIT", "group___vectors__module.html#ga0feccbc3105c1218d4b42a36883225b2", null ]
];