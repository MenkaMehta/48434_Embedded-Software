var unionuint32union__t =
[
    [ "Hi", "unionuint32union__t.html#a94656d765a83aeacf2f5a878d2e724d5", null ],
    [ "l", "unionuint32union__t.html#a02b7aaa4708411c52446dc5528f66c25", null ],
    [ "Lo", "unionuint32union__t.html#af2e434db784d503f1adf796fe2a5ebdd", null ],
    [ "s", "unionuint32union__t.html#a00b12f209c91b64c009f2eecafd298c2", null ]
];