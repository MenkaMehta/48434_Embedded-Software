var struct_l_d_d___u_s_b___t_device_feature_request___struct =
[
    [ "bmRequestType", "struct_l_d_d___u_s_b___t_device_feature_request___struct.html#a8258c0deaca59b3bd0c4d39c0dca9637", null ],
    [ "bRequest", "struct_l_d_d___u_s_b___t_device_feature_request___struct.html#a7dbfead1667063e1e2e7fb608362606a", null ],
    [ "wFeatureSelector", "struct_l_d_d___u_s_b___t_device_feature_request___struct.html#a74dbb226786321c02ccad64b067b4ebe", null ],
    [ "wIndex", "struct_l_d_d___u_s_b___t_device_feature_request___struct.html#a261267b70741fe26898665df42fec10b", null ],
    [ "wLength", "struct_l_d_d___u_s_b___t_device_feature_request___struct.html#af0c222aa4585a132b2582fb1c290edc7", null ]
];