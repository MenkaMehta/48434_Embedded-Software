var group___w_d_o_g___peripheral =
[
    [ "WDOG - Register accessor macros", "group___w_d_o_g___register___accessor___macros.html", null ],
    [ "WDOG Register Masks", "group___w_d_o_g___register___masks.html", null ],
    [ "WDOG_MemMap", "struct_w_d_o_g___mem_map.html", [
      [ "PRESC", "struct_w_d_o_g___mem_map.html#a8d00541f19094160ea06d8c7ded60298", null ],
      [ "REFRESH", "struct_w_d_o_g___mem_map.html#a5dbb3963b38571b0de1d2db7bd89d46a", null ],
      [ "RSTCNT", "struct_w_d_o_g___mem_map.html#aad95a949933f4c578786a38a2ffeec4a", null ],
      [ "STCTRLH", "struct_w_d_o_g___mem_map.html#ae48286fe7c8ceabfd9aa616e40b52a35", null ],
      [ "STCTRLL", "struct_w_d_o_g___mem_map.html#a0eb14eade4d91bd2f2f82910d633e0aa", null ],
      [ "TMROUTH", "struct_w_d_o_g___mem_map.html#a47bce5f5c4ea1609ec9d0055e05e9b73", null ],
      [ "TMROUTL", "struct_w_d_o_g___mem_map.html#a873a6456ac56cb42a5a2ff66ddfefa3c", null ],
      [ "TOVALH", "struct_w_d_o_g___mem_map.html#ae5ac6a42d85914d2f739b5377734f87a", null ],
      [ "TOVALL", "struct_w_d_o_g___mem_map.html#a2ce5a77ef35f55b7f60a11757dbd758f", null ],
      [ "UNLOCK", "struct_w_d_o_g___mem_map.html#a78988c0aeb0693a231757a4cc164e1bf", null ],
      [ "WINH", "struct_w_d_o_g___mem_map.html#a86589dc11cb4b7d3a00be9234372591f", null ],
      [ "WINL", "struct_w_d_o_g___mem_map.html#af238938251c1f5904a215c8a4ed1b74d", null ]
    ] ],
    [ "WDOG_BASE_PTR", "group___w_d_o_g___peripheral.html#ga72fb27c7bc1ae124f180d8f2c7b9fa79", null ],
    [ "WDOG_BASE_PTRS", "group___w_d_o_g___peripheral.html#ga8d50dba3756857eed1783b3d726d40d8", null ],
    [ "WDOG_MemMapPtr", "group___w_d_o_g___peripheral.html#gaed99974fa14a19f21a8770728ff09af3", null ]
];