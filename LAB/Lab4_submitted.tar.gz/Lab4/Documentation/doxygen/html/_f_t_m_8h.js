var _f_t_m_8h =
[
    [ "TFTMChannel", "struct_t_f_t_m_channel.html", "struct_t_f_t_m_channel" ],
    [ "TTimerFunction", "_f_t_m_8h.html#a830315c3626b559a4ec857bef198cf7b", [
      [ "TIMER_FUNCTION_INPUT_CAPTURE", "_f_t_m_8h.html#a830315c3626b559a4ec857bef198cf7bacd39a068bcbbb1c56c56097cd04aed14", null ],
      [ "TIMER_FUNCTION_OUTPUT_COMPARE", "_f_t_m_8h.html#a830315c3626b559a4ec857bef198cf7ba4f02c6bf4ba334adb3911ffb59f21265", null ]
    ] ],
    [ "TTimerInputDetection", "_f_t_m_8h.html#a94108be49a2464d06bf383b3dc1a218e", [
      [ "TIMER_INPUT_OFF", "_f_t_m_8h.html#a94108be49a2464d06bf383b3dc1a218ead2de7a920acc78d64016ecc1808020ae", null ],
      [ "TIMER_INPUT_RISING", "_f_t_m_8h.html#a94108be49a2464d06bf383b3dc1a218eae63dbaff41e32ecec4fc3c73892d727f", null ],
      [ "TIMER_INPUT_FALLING", "_f_t_m_8h.html#a94108be49a2464d06bf383b3dc1a218eabb925337aa448aab1a5912de487715cb", null ],
      [ "TIMER_INPUT_ANY", "_f_t_m_8h.html#a94108be49a2464d06bf383b3dc1a218ea28560fff866737910cad27acec699fea", null ]
    ] ],
    [ "TTimerOutputAction", "_f_t_m_8h.html#ad5f2367d930015e42d1b0db18249ac44", [
      [ "TIMER_OUTPUT_DISCONNECT", "_f_t_m_8h.html#ad5f2367d930015e42d1b0db18249ac44a256de8e3014a3e20f26c283b9a8ec73c", null ],
      [ "TIMER_OUTPUT_TOGGLE", "_f_t_m_8h.html#ad5f2367d930015e42d1b0db18249ac44aa7803dfea664e01b0ef2dadbc0c16000", null ],
      [ "TIMER_OUTPUT_LOW", "_f_t_m_8h.html#ad5f2367d930015e42d1b0db18249ac44a87c191c13faff5c88cf2ce25392eadf7", null ],
      [ "TIMER_OUTPUT_HIGH", "_f_t_m_8h.html#ad5f2367d930015e42d1b0db18249ac44a4d9dddf39ebaa0d153792ef3b97b61c4", null ]
    ] ],
    [ "__attribute__", "_f_t_m_8h.html#ae6201ca1698a806c13f301d498977d59", null ],
    [ "FTM_Init", "_f_t_m_8h.html#a3687c17e07a3faa0cf0cbec2a6639b74", null ],
    [ "FTM_Set", "_f_t_m_8h.html#ac8d7110bd0a928b78407114222dc279b", null ],
    [ "FTM_StartTimer", "_f_t_m_8h.html#afadfa05ab10215491e093bb886c0e389", null ]
];