var struct_l_d_d___s_d_h_c___t_card_caps =
[
    [ "DataWidths", "struct_l_d_d___s_d_h_c___t_card_caps.html#a79fc1f5a77986075f37dfc967fc7e839", null ],
    [ "Erase", "struct_l_d_d___s_d_h_c___t_card_caps.html#afc5bbe5bce7267f930d6e8501ac5d2ea", null ],
    [ "HighCapacity", "struct_l_d_d___s_d_h_c___t_card_caps.html#aecde13a16eb437017641776270f9479c", null ],
    [ "HighSpeed", "struct_l_d_d___s_d_h_c___t_card_caps.html#a382fb9e854ee58ba00f5e390345dad9c", null ],
    [ "LowVoltage", "struct_l_d_d___s_d_h_c___t_card_caps.html#a283a376bda2540641d83cde61d1e0188", null ],
    [ "Operations", "struct_l_d_d___s_d_h_c___t_card_caps.html#a4af30c5df5445720a0da2f6abdcc9629", null ],
    [ "Read", "struct_l_d_d___s_d_h_c___t_card_caps.html#ae5a39842e7b8c28f9246d3fc1b9a8f54", null ],
    [ "Write", "struct_l_d_d___s_d_h_c___t_card_caps.html#ad28c378a6b9edfbd726a8019d5c8be79", null ],
    [ "WriteProtect", "struct_l_d_d___s_d_h_c___t_card_caps.html#a32ecbbace3b435b1d70a57b09bf9662b", null ]
];