var group___core_debug___peripheral =
[
    [ "CoreDebug - Register accessor macros", "group___core_debug___register___accessor___macros.html", null ],
    [ "CoreDebug Register Masks", "group___core_debug___register___masks.html", null ],
    [ "CoreDebug_MemMap", "struct_core_debug___mem_map.html", [
      [ "base_DCRDR", "struct_core_debug___mem_map.html#aac76a717b2aba2ccbf75e020cc71fb3e", null ],
      [ "base_DCRSR", "struct_core_debug___mem_map.html#ad9c98f7390e5d3a6b54df56ddea32e8b", null ],
      [ "base_DEMCR", "struct_core_debug___mem_map.html#a13a099e668fcb3587b2cd6eb8f8608d5", null ],
      [ "base_DHCSR_Read", "struct_core_debug___mem_map.html#a4968901505f61e2a98c9196a8ac7584b", null ],
      [ "base_DHCSR_Write", "struct_core_debug___mem_map.html#a57de52c8c1eb5789546543f2408ce487", null ]
    ] ],
    [ "CoreDebug_BASE_PTR", "group___core_debug___peripheral.html#ga994a185afca30ede538d89322c4f0326", null ],
    [ "CoreDebug_BASE_PTRS", "group___core_debug___peripheral.html#gaceec19d257d8b9f9bff5d47d285dec27", null ],
    [ "CoreDebug_MemMapPtr", "group___core_debug___peripheral.html#gaa548220bc91b12bd49065fe752579fcd", null ]
];