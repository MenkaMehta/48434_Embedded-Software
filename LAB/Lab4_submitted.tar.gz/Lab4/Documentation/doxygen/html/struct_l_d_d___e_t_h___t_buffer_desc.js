var struct_l_d_d___e_t_h___t_buffer_desc =
[
    [ "DataPtr", "struct_l_d_d___e_t_h___t_buffer_desc.html#af9049f0d40faa480a4de3532a1de4605", null ],
    [ "Size", "struct_l_d_d___e_t_h___t_buffer_desc.html#abddc4273b732d3cf44ff0b6870d6b87a", null ]
];