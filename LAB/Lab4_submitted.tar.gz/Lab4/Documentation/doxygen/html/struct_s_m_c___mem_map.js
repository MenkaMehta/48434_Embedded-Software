var struct_s_m_c___mem_map =
[
    [ "PMCTRL", "struct_s_m_c___mem_map.html#a2a5d946bb55640fd179c4065937bea5c", null ],
    [ "PMPROT", "struct_s_m_c___mem_map.html#afd03d93a7823dc65f53216dca15a2a95", null ],
    [ "PMSTAT", "struct_s_m_c___mem_map.html#a0fddef87e229c4cf1b3be0d29589e964", null ],
    [ "VLLSCTRL", "struct_s_m_c___mem_map.html#ad5b37041739800b7bb7afc59d53c7ded", null ]
];