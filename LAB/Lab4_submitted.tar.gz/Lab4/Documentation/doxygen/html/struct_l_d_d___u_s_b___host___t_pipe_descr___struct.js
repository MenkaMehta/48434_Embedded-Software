var struct_l_d_d___u_s_b___host___t_pipe_descr___struct =
[
    [ "DevAddress", "struct_l_d_d___u_s_b___host___t_pipe_descr___struct.html#a271b448f22a234e626c76ef6e608950f", null ],
    [ "DevSpeed", "struct_l_d_d___u_s_b___host___t_pipe_descr___struct.html#a4343db25b1f0491f0ffd98878bd638d7", null ],
    [ "EpDir", "struct_l_d_d___u_s_b___host___t_pipe_descr___struct.html#a2f047311da347469505ed4aa6da98bf3", null ],
    [ "EpNumber", "struct_l_d_d___u_s_b___host___t_pipe_descr___struct.html#a7232e8ba8065c9f9e9151c6a8b71dfc1", null ],
    [ "Flags", "struct_l_d_d___u_s_b___host___t_pipe_descr___struct.html#a2cc4699b0d6a2f8c557bd3518416dee3", null ],
    [ "Interval", "struct_l_d_d___u_s_b___host___t_pipe_descr___struct.html#aa5d61972673a26e9c87fd43dab29ec7b", null ],
    [ "MaxPacketSize", "struct_l_d_d___u_s_b___host___t_pipe_descr___struct.html#a0d5896a2345e83eb9162806de485a35a", null ],
    [ "NAKCount", "struct_l_d_d___u_s_b___host___t_pipe_descr___struct.html#a26305ab78bd58ccf7d31aeb1671c2e0e", null ],
    [ "TransferType", "struct_l_d_d___u_s_b___host___t_pipe_descr___struct.html#a42bf0ec64bda6f7f31d32e3f4cd5df13", null ],
    [ "TrPerUFrame", "struct_l_d_d___u_s_b___host___t_pipe_descr___struct.html#adb11454d0380a421cf7ab4fc225e5c41", null ]
];