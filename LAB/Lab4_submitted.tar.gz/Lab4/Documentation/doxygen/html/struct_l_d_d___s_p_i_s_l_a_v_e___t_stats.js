var struct_l_d_d___s_p_i_s_l_a_v_e___t_stats =
[
    [ "RxChars", "struct_l_d_d___s_p_i_s_l_a_v_e___t_stats.html#a91f6acf13143110968772d344d352fc6", null ],
    [ "RxOverruns", "struct_l_d_d___s_p_i_s_l_a_v_e___t_stats.html#a82edd5dc5e18e7cd6a047d0efbda97ae", null ],
    [ "RxParityErrors", "struct_l_d_d___s_p_i_s_l_a_v_e___t_stats.html#abef442625b92cf52c2ff04edf6894dd3", null ],
    [ "TxChars", "struct_l_d_d___s_p_i_s_l_a_v_e___t_stats.html#ab674ba50318e198a1ee9dea0692ce239", null ],
    [ "TxUnderruns", "struct_l_d_d___s_p_i_s_l_a_v_e___t_stats.html#ab2e5342f4a486b20ae9306f451451a77", null ]
];