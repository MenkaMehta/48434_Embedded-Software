var struct_t_f_i_f_o =
[
    [ "Buffer", "struct_t_f_i_f_o.html#a5a9d712880dc4f1d5571b96452cd85f8", null ],
    [ "End", "struct_t_f_i_f_o.html#a5063b875898a6f23a97aa3ca17f0544b", null ],
    [ "NbBytes", "struct_t_f_i_f_o.html#ace00017651a266a66a93aa5220967611", null ],
    [ "Start", "struct_t_f_i_f_o.html#a092a7559431a12616672354641908167", null ]
];