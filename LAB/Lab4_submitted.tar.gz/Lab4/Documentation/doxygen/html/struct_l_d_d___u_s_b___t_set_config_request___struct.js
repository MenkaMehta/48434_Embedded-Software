var struct_l_d_d___u_s_b___t_set_config_request___struct =
[
    [ "bmRequestType", "struct_l_d_d___u_s_b___t_set_config_request___struct.html#aa3e4ca8e83424e5496478991dac0361a", null ],
    [ "bRequest", "struct_l_d_d___u_s_b___t_set_config_request___struct.html#a12a9d3e8bd01f75b681c1749d2595f42", null ],
    [ "bValueHigh", "struct_l_d_d___u_s_b___t_set_config_request___struct.html#a55df59e0060cfd0bc6e9bdc53b9a0d99", null ],
    [ "ConfigNumber", "struct_l_d_d___u_s_b___t_set_config_request___struct.html#a9a545d7858a7ee85dbe37eaf2b4b7e01", null ],
    [ "wIndex", "struct_l_d_d___u_s_b___t_set_config_request___struct.html#ad2aa2851b128777e842b2ac796d2f664", null ],
    [ "wLength", "struct_l_d_d___u_s_b___t_set_config_request___struct.html#a66312977eb5816459d0201a2bacaf9b5", null ]
];