var struct_l_d_d___s_d_h_c___t_card_info =
[
    [ "BlockCount", "struct_l_d_d___s_d_h_c___t_card_info.html#aaf0587f4fc0e52a160d0ac2a1106c4e9", null ],
    [ "BlockLength", "struct_l_d_d___s_d_h_c___t_card_info.html#a46cbdea4ece83eeaa17410e9763cc3a9", null ],
    [ "Caps", "struct_l_d_d___s_d_h_c___t_card_info.html#a591c22d1aa49944325b35c63d2bf8199", null ],
    [ "Type", "struct_l_d_d___s_d_h_c___t_card_info.html#ab2b86f6fe821778459edd351d08eb4bd", null ]
];