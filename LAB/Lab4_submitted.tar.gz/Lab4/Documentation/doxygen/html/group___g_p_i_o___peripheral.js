var group___g_p_i_o___peripheral =
[
    [ "GPIO - Register accessor macros", "group___g_p_i_o___register___accessor___macros.html", null ],
    [ "GPIO Register Masks", "group___g_p_i_o___register___masks.html", null ],
    [ "GPIO_MemMap", "struct_g_p_i_o___mem_map.html", [
      [ "PCOR", "struct_g_p_i_o___mem_map.html#a996f6a159415a5c0d0683346e950e7fb", null ],
      [ "PDDR", "struct_g_p_i_o___mem_map.html#a49dfaa95d08fa9178dd7f098c87f562d", null ],
      [ "PDIR", "struct_g_p_i_o___mem_map.html#a01933bea5d005bf126ea2e0345518763", null ],
      [ "PDOR", "struct_g_p_i_o___mem_map.html#aaf4f486952b9b4680e270ce6266122fd", null ],
      [ "PSOR", "struct_g_p_i_o___mem_map.html#a14833f065ec123137ccce5ab873b5879", null ],
      [ "PTOR", "struct_g_p_i_o___mem_map.html#a03faa882b5f4554ff4c11954c2d8759b", null ]
    ] ],
    [ "GPIO_BASE_PTRS", "group___g_p_i_o___peripheral.html#gad0f7206167a584b1e75a81a5c30fa1c2", null ],
    [ "PTA_BASE_PTR", "group___g_p_i_o___peripheral.html#gadf98f6ee2bbfd42102e378a66b29b9ef", null ],
    [ "PTB_BASE_PTR", "group___g_p_i_o___peripheral.html#ga59ab0f28e891ea28f152505ce2021747", null ],
    [ "PTC_BASE_PTR", "group___g_p_i_o___peripheral.html#gaaa3dc05c2a51a960067e1de6863fd3dd", null ],
    [ "PTD_BASE_PTR", "group___g_p_i_o___peripheral.html#gaa61d2c33375f3becbae1353eee4c1317", null ],
    [ "PTE_BASE_PTR", "group___g_p_i_o___peripheral.html#gaa230685f72ad1540850ab8d12366775c", null ],
    [ "PTF_BASE_PTR", "group___g_p_i_o___peripheral.html#ga77d3c9297d0f81182ffcc68c0096eb1a", null ],
    [ "GPIO_MemMapPtr", "group___g_p_i_o___peripheral.html#ga31c1eddda45aa085f51142987e05ada5", null ]
];