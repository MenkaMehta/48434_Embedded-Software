var struct_g_p_i_o___mem_map =
[
    [ "PCOR", "struct_g_p_i_o___mem_map.html#a996f6a159415a5c0d0683346e950e7fb", null ],
    [ "PDDR", "struct_g_p_i_o___mem_map.html#a49dfaa95d08fa9178dd7f098c87f562d", null ],
    [ "PDIR", "struct_g_p_i_o___mem_map.html#a01933bea5d005bf126ea2e0345518763", null ],
    [ "PDOR", "struct_g_p_i_o___mem_map.html#aaf4f486952b9b4680e270ce6266122fd", null ],
    [ "PSOR", "struct_g_p_i_o___mem_map.html#a14833f065ec123137ccce5ab873b5879", null ],
    [ "PTOR", "struct_g_p_i_o___mem_map.html#a03faa882b5f4554ff4c11954c2d8759b", null ]
];