var group___s_m_c___peripheral =
[
    [ "SMC - Register accessor macros", "group___s_m_c___register___accessor___macros.html", null ],
    [ "SMC Register Masks", "group___s_m_c___register___masks.html", null ],
    [ "SMC_MemMap", "struct_s_m_c___mem_map.html", [
      [ "PMCTRL", "struct_s_m_c___mem_map.html#a2a5d946bb55640fd179c4065937bea5c", null ],
      [ "PMPROT", "struct_s_m_c___mem_map.html#afd03d93a7823dc65f53216dca15a2a95", null ],
      [ "PMSTAT", "struct_s_m_c___mem_map.html#a0fddef87e229c4cf1b3be0d29589e964", null ],
      [ "VLLSCTRL", "struct_s_m_c___mem_map.html#ad5b37041739800b7bb7afc59d53c7ded", null ]
    ] ],
    [ "SMC_BASE_PTR", "group___s_m_c___peripheral.html#ga31b6c4571795341e6446800243313e56", null ],
    [ "SMC_BASE_PTRS", "group___s_m_c___peripheral.html#gae583f3f0917ee513adcac36dd042a5f3", null ],
    [ "SMC_MemMapPtr", "group___s_m_c___peripheral.html#ga763f87a6b8ebab7acb6dde639e6a47c7", null ]
];