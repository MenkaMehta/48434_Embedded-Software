var _i2_c_8h =
[
    [ "TI2CModule", "struct_t_i2_c_module.html", "struct_t_i2_c_module" ],
    [ "I2C_Init", "_i2_c_8h.html#af5a1731e099294a5bda6ef0f14aeb547", null ],
    [ "I2C_Read", "_i2_c_8h.html#a03054e2b5a4678e9b31dad8ccee6a2cc", null ],
    [ "I2C_SelectSlaveDevice", "_i2_c_8h.html#a0d6844ce590bbf5cc557fdf0747ad551", null ],
    [ "I2C_Write", "_i2_c_8h.html#acaac94d86a7213791fb691d57c6f278b", null ]
];