var struct_l_d_d___u_s_b___t_ep_descriptor___struct =
[
    [ "bDescriptorType", "struct_l_d_d___u_s_b___t_ep_descriptor___struct.html#aecc71d9488627adeb5f7de1e71fc45d1", null ],
    [ "bEndpointAddress", "struct_l_d_d___u_s_b___t_ep_descriptor___struct.html#a62745d5a897f76419a136579b2fbca02", null ],
    [ "bInterval", "struct_l_d_d___u_s_b___t_ep_descriptor___struct.html#a17aac2d9a945d37748eb0422bb811df2", null ],
    [ "bLength", "struct_l_d_d___u_s_b___t_ep_descriptor___struct.html#ad4cc2b6088c7fb913f40eada94098393", null ],
    [ "bmAttributes", "struct_l_d_d___u_s_b___t_ep_descriptor___struct.html#a7a3e6205355d7fa84899f23ac8e58490", null ],
    [ "wMaxPacketSize", "struct_l_d_d___u_s_b___t_ep_descriptor___struct.html#a19e3e6b0524f2fcd25377f008c94c3c6", null ]
];