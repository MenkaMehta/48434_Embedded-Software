var struct_l_d_d___a_d_c___t_pin_mask =
[
    [ "Channel0_31PinMask", "struct_l_d_d___a_d_c___t_pin_mask.html#a66d94f79f603c74c93540553a49bbf3f", null ],
    [ "Channel32_63PinMask", "struct_l_d_d___a_d_c___t_pin_mask.html#acd6bf6f512fb6e8cd170188dc663a4d8", null ],
    [ "TriggerPinMask", "struct_l_d_d___a_d_c___t_pin_mask.html#a004a4d3a4f4071684e6676f64322215f", null ],
    [ "VoltRefPinMask", "struct_l_d_d___a_d_c___t_pin_mask.html#a556430a91304e7db634bda25091b892c", null ]
];