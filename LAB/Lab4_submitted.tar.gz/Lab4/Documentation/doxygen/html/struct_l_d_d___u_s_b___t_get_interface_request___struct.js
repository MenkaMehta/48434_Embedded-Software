var struct_l_d_d___u_s_b___t_get_interface_request___struct =
[
    [ "bmRequestType", "struct_l_d_d___u_s_b___t_get_interface_request___struct.html#a2b04fcd64b22914d50af67b1b44dcb36", null ],
    [ "bRequest", "struct_l_d_d___u_s_b___t_get_interface_request___struct.html#a322309595b9cbe6bb0a391d463138e3d", null ],
    [ "wInterface", "struct_l_d_d___u_s_b___t_get_interface_request___struct.html#ac3dc3f80a292a73950254f8ce4c99a73", null ],
    [ "wLength", "struct_l_d_d___u_s_b___t_get_interface_request___struct.html#a2aa1550fc5e72002a94c74ea0957ec74", null ],
    [ "wWalue", "struct_l_d_d___u_s_b___t_get_interface_request___struct.html#a48bcaf6af044e3e9669f5ea634a2b9fe", null ]
];