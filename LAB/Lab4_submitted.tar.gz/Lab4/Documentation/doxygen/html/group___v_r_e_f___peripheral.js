var group___v_r_e_f___peripheral =
[
    [ "VREF - Register accessor macros", "group___v_r_e_f___register___accessor___macros.html", null ],
    [ "VREF Register Masks", "group___v_r_e_f___register___masks.html", null ],
    [ "VREF_MemMap", "struct_v_r_e_f___mem_map.html", [
      [ "SC", "struct_v_r_e_f___mem_map.html#a5d8e7e9026a69a14ff0d0b3caee5cf24", null ],
      [ "TRM", "struct_v_r_e_f___mem_map.html#a987ecd280eb0b25ff58841b304de2e1f", null ]
    ] ],
    [ "VREF_BASE_PTR", "group___v_r_e_f___peripheral.html#ga53dba79dbefcdd6f788740a6d0caa57d", null ],
    [ "VREF_BASE_PTRS", "group___v_r_e_f___peripheral.html#ga3eb17aee5de4a519ee18fe763e43865b", null ],
    [ "VREF_MemMapPtr", "group___v_r_e_f___peripheral.html#ga0730b01086e1d40975ad4e6c1d101b7c", null ]
];