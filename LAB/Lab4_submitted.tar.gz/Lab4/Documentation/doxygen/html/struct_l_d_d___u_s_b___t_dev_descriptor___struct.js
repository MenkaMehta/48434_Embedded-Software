var struct_l_d_d___u_s_b___t_dev_descriptor___struct =
[
    [ "bcdDevice", "struct_l_d_d___u_s_b___t_dev_descriptor___struct.html#ab5ed57c271bb34676c0074942f40fd24", null ],
    [ "bcdUSB", "struct_l_d_d___u_s_b___t_dev_descriptor___struct.html#af78882a5888196664c86e334f2be35c2", null ],
    [ "bDescriptorType", "struct_l_d_d___u_s_b___t_dev_descriptor___struct.html#ad5ce775d75a2e1f139b1cd74f89854cf", null ],
    [ "bDeviceClass", "struct_l_d_d___u_s_b___t_dev_descriptor___struct.html#af0bf5f3b57b927cb04613bb888fd1e90", null ],
    [ "bDeviceProtocol", "struct_l_d_d___u_s_b___t_dev_descriptor___struct.html#a9a49b20d1bd0c7f39345e3963645636d", null ],
    [ "bDeviceSubClass", "struct_l_d_d___u_s_b___t_dev_descriptor___struct.html#aaaa3f52ada623e59338fbba8670bb3bd", null ],
    [ "bLength", "struct_l_d_d___u_s_b___t_dev_descriptor___struct.html#a786fc767e0651f6b7146fc691f66747d", null ],
    [ "bMaxPacketSize0", "struct_l_d_d___u_s_b___t_dev_descriptor___struct.html#a4f0c4e61ccb6ed2bdccdb6b6fbd8c95c", null ],
    [ "bNumConfigurations", "struct_l_d_d___u_s_b___t_dev_descriptor___struct.html#ab1e1436818c6ff3060a56bb136f07648", null ],
    [ "idProduct", "struct_l_d_d___u_s_b___t_dev_descriptor___struct.html#a70f350fe88205de699efe58fdb60e3d4", null ],
    [ "idVendor", "struct_l_d_d___u_s_b___t_dev_descriptor___struct.html#a3ca2eabe9034c627759b9c3435f4ac62", null ],
    [ "iManufacturer", "struct_l_d_d___u_s_b___t_dev_descriptor___struct.html#a08ef46915ceb0b4b3cda58d586522ddf", null ],
    [ "iProduct", "struct_l_d_d___u_s_b___t_dev_descriptor___struct.html#a224063a7358f7be5c56f88576d380a38", null ],
    [ "iSerialNumber", "struct_l_d_d___u_s_b___t_dev_descriptor___struct.html#a20a21f9aa226246239ca51ec4fd9438f", null ]
];