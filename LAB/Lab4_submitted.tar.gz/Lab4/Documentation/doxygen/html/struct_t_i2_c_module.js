var struct_t_i2_c_module =
[
    [ "baudRate", "struct_t_i2_c_module.html#ad03b4abd3fe582e000053d272103ca2c", null ],
    [ "primarySlaveAddress", "struct_t_i2_c_module.html#a47196c499db62742e6483617bdf54a28", null ]
];