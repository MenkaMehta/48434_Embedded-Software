var struct_l_d_d___f_l_a_s_h___t_error_status =
[
    [ "CurrentAddress", "struct_l_d_d___f_l_a_s_h___t_error_status.html#aede15779720f091b04e8fb4b423dc654", null ],
    [ "CurrentCommand", "struct_l_d_d___f_l_a_s_h___t_error_status.html#a8121cb2540ba191287d219e4f1a675dd", null ],
    [ "CurrentDataPtr", "struct_l_d_d___f_l_a_s_h___t_error_status.html#a2c071a468d63d1572589e327dfe46fd4", null ],
    [ "CurrentDataSize", "struct_l_d_d___f_l_a_s_h___t_error_status.html#ab7c77ef770367308c125aa95c4f0e465", null ],
    [ "CurrentErrorFlags", "struct_l_d_d___f_l_a_s_h___t_error_status.html#a1f8e3f3fd6ceb25960d234254aee7e13", null ],
    [ "CurrentOperation", "struct_l_d_d___f_l_a_s_h___t_error_status.html#aa1b99bfba14fdc8379522df15da47e7b", null ]
];