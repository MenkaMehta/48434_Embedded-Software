var main_8c =
[
    [ "BAUDRATE", "group__main__module.html#ga734bbab06e1a9fd2e5522db0221ff6e3", null ],
    [ "MODULE_CLOCK", "group__main__module.html#ga330f2bac61ce194d744c0c15bd4a43f5", null ],
    [ "main", "group__main__module.html#ga840291bc02cba5474a4cb46a9b9566fe", null ]
];