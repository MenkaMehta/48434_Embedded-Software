var struct_u_s_b_d_c_d___mem_map =
[
    [ "CLOCK", "struct_u_s_b_d_c_d___mem_map.html#a86ba3b0e7a077a4b9afbe207f335216c", null ],
    [ "CONTROL", "struct_u_s_b_d_c_d___mem_map.html#a6d1149f9d598e71d5f6d5cf12ab1a5d5", null ],
    [ "RESERVED_0", "struct_u_s_b_d_c_d___mem_map.html#aeeaa1cbcb5736bfa5b4a3c025d6b2840", null ],
    [ "STATUS", "struct_u_s_b_d_c_d___mem_map.html#aef7d6303adc8b41b479d65f8f1d4c3e2", null ],
    [ "TIMER0", "struct_u_s_b_d_c_d___mem_map.html#aecfb36e34db08abcd8984d10a9f87e7c", null ],
    [ "TIMER1", "struct_u_s_b_d_c_d___mem_map.html#aa8bcdbeba3cbd7a27281d317ba5484e9", null ],
    [ "TIMER2", "struct_u_s_b_d_c_d___mem_map.html#abaa84a33ed5173cf08f87f3590a3f035", null ]
];