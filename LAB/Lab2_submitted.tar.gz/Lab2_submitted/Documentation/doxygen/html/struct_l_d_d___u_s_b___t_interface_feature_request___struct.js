var struct_l_d_d___u_s_b___t_interface_feature_request___struct =
[
    [ "bmRequestType", "struct_l_d_d___u_s_b___t_interface_feature_request___struct.html#a72b3bba6305033e1951402155005aa7d", null ],
    [ "bRequest", "struct_l_d_d___u_s_b___t_interface_feature_request___struct.html#a5e8ab52b3b2c853ee77a5e2207aaf01b", null ],
    [ "wFeatureSelector", "struct_l_d_d___u_s_b___t_interface_feature_request___struct.html#aa1c03cac467205263f3f973f580dca11", null ],
    [ "wInterface", "struct_l_d_d___u_s_b___t_interface_feature_request___struct.html#afc1da433b4a02f8c6a6ed6ce8b3065da", null ],
    [ "wLength", "struct_l_d_d___u_s_b___t_interface_feature_request___struct.html#a5f54f1e83024342d9d63aad374a117ba", null ]
];