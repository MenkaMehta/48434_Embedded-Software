var struct_l_d_d___s_s_i___t_stats =
[
    [ "RxChars", "struct_l_d_d___s_s_i___t_stats.html#ac77cdfd687b197b589fbcd43856aeb98", null ],
    [ "RxChars1", "struct_l_d_d___s_s_i___t_stats.html#ae5221a07e2a6ad3907c34007693dbc55", null ],
    [ "RxOverruns", "struct_l_d_d___s_s_i___t_stats.html#aa2125ae18425d2e4bd193b1ee434c8d9", null ],
    [ "RxOverruns1", "struct_l_d_d___s_s_i___t_stats.html#af0efb66c36bfe377efb18e6ab2fe4559", null ],
    [ "TxChars", "struct_l_d_d___s_s_i___t_stats.html#abaff1182d41c2c211ce8da947df77bbd", null ],
    [ "TxChars1", "struct_l_d_d___s_s_i___t_stats.html#a0721d681a52cc566e4c89de10e962923", null ],
    [ "TxUnderruns", "struct_l_d_d___s_s_i___t_stats.html#a5ac8911e76989013a9a4757a90aa5660", null ],
    [ "TxUnderruns1", "struct_l_d_d___s_s_i___t_stats.html#a14fb329147ead1d214cd25ffd3b39f6d", null ]
];