var group___m_c_m___peripheral =
[
    [ "MCM - Register accessor macros", "group___m_c_m___register___accessor___macros.html", null ],
    [ "MCM Register Masks", "group___m_c_m___register___masks.html", null ],
    [ "MCM_MemMap", "struct_m_c_m___mem_map.html", [
      [ "CR", "struct_m_c_m___mem_map.html#a7bc89132595b7fb75318b4ba285957cd", null ],
      [ "ETBCC", "struct_m_c_m___mem_map.html#a2d99ca168bd0840c724da29daca2c355", null ],
      [ "ETBCNT", "struct_m_c_m___mem_map.html#adfc2ce9910687ae02d33cb7a1584a919", null ],
      [ "ETBRL", "struct_m_c_m___mem_map.html#ae4d8c3979038482e324840c3bfa856d7", null ],
      [ "FADR", "struct_m_c_m___mem_map.html#a24197ee74384716a50d20fcff8808e23", null ],
      [ "FATR", "struct_m_c_m___mem_map.html#abb947ea49f229a18c367c028b2512619", null ],
      [ "FDR", "struct_m_c_m___mem_map.html#a39ba2ce19e224175a9164c1781bf16c3", null ],
      [ "ISCR", "struct_m_c_m___mem_map.html#a69e6005b95d37157e53bfcd24535c55e", null ],
      [ "PID", "struct_m_c_m___mem_map.html#a41b1890f596f706bcd94c2d49c1e44f7", null ],
      [ "PLAMC", "struct_m_c_m___mem_map.html#a7d749b910777a6b67ea94f2379c628ee", null ],
      [ "PLASC", "struct_m_c_m___mem_map.html#ad68f64d82524bb0b181a837967b8e248", null ],
      [ "RESERVED_0", "struct_m_c_m___mem_map.html#aa03546833695c701bce946849c4acf8b", null ],
      [ "RESERVED_1", "struct_m_c_m___mem_map.html#a53939a8fb4282543d229a1e45bf91edf", null ]
    ] ],
    [ "MCM_BASE_PTR", "group___m_c_m___peripheral.html#gad41e931f176c230831e3dbad45117841", null ],
    [ "MCM_BASE_PTRS", "group___m_c_m___peripheral.html#gae2d5e838ce7d2d4108738c05bf224272", null ],
    [ "MCM_MemMapPtr", "group___m_c_m___peripheral.html#ga72e8bbe428d9410917903164d3a5f675", null ]
];