var struct_r_f_s_y_s___mem_map =
[
    [ "REG", "struct_r_f_s_y_s___mem_map.html#a9ecc7686e575e2e1570cf50aa3234276", null ]
];