var struct_l_d_d___u_s_b___t_endpoint_status_request___struct =
[
    [ "bEndpoint", "struct_l_d_d___u_s_b___t_endpoint_status_request___struct.html#af6e2c04625ae0703ac3eedd82cbf1fe3", null ],
    [ "bIndexHigh", "struct_l_d_d___u_s_b___t_endpoint_status_request___struct.html#a0d53fe67e57b45eff01799aaa5720987", null ],
    [ "bmRequestType", "struct_l_d_d___u_s_b___t_endpoint_status_request___struct.html#a2d7155b7316be76989c9c2ff3be46bca", null ],
    [ "bRequest", "struct_l_d_d___u_s_b___t_endpoint_status_request___struct.html#ae8ab1e11dae5a0b3a4b4a7256a542175", null ],
    [ "wLength", "struct_l_d_d___u_s_b___t_endpoint_status_request___struct.html#addba57e934f9c77c9159d7be618dd6dc", null ],
    [ "wValue", "struct_l_d_d___u_s_b___t_endpoint_status_request___struct.html#a987fe8c9322a22d8b5118eccd4de42c8", null ]
];