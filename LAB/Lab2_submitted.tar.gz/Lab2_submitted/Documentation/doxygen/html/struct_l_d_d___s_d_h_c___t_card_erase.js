var struct_l_d_d___s_d_h_c___t_card_erase =
[
    [ "Pattern", "struct_l_d_d___s_d_h_c___t_card_erase.html#a440e717a0c559282b7e277bf0872bee3", null ],
    [ "SectorSize", "struct_l_d_d___s_d_h_c___t_card_erase.html#a3c0c33e89b65f4f6bfd6043585df5486", null ]
];